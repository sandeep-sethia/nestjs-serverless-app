export declare class InfoModule {
}
