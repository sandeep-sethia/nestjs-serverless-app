import { InfoService } from './info.service';
export declare class InfoController {
    private readonly infoService;
    constructor(infoService: InfoService);
    getServiceInfo(): Promise<{
        api_name: string;
        version: string;
    }>;
}
