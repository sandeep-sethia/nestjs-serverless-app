export declare class InfoService {
    getInfo(): Promise<{
        api_name: string;
        version: string;
    }>;
}
