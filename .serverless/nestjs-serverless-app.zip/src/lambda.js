"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_serverless_express_1 = require("aws-serverless-express");
const middleware_1 = require("aws-serverless-express/middleware");
const core_1 = require("@nestjs/core");
const platform_express_1 = require("@nestjs/platform-express");
const bodyParser = __importStar(require("body-parser"));
const app_module_1 = require("./app.module");
const express_1 = __importDefault(require("express"));
const binaryMimeTypes = ['image/jpeg', 'image/png', 'image/gif'];
let cachedServer;
async function bootstrapServer() {
    if (!cachedServer) {
        const expressApp = express_1.default();
        const nestApp = await core_1.NestFactory.create(app_module_1.AppModule, new platform_express_1.ExpressAdapter(expressApp));
        nestApp.use(bodyParser.json({ limit: '10mb' }));
        nestApp.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));
        nestApp.use(middleware_1.eventContext());
        await nestApp.init();
        cachedServer = aws_serverless_express_1.createServer(expressApp, undefined, binaryMimeTypes);
    }
    return cachedServer;
}
exports.handler = async (event, context) => {
    cachedServer = await bootstrapServer();
    return aws_serverless_express_1.proxy(cachedServer, event, context, 'PROMISE').promise;
};
//# sourceMappingURL=lambda.js.map